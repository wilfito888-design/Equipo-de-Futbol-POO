/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.equipofutbol.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pc
 */
public class Equipo {
    
    private String nombre;
    private String pais;
    private Mascota mascota;
    private Portero portero;
    private List<Delantero> delanteros;

    public Equipo(String nombre, String pais) {
        this.nombre = nombre;
        this.pais = pais;
        this.mascota = new Mascota("Mascota Oficial", "Desconocido", "Por definir");
        this.portero = null;
        this.delanteros = new ArrayList<>();
    }

    public Equipo(String nombre, String pais, String nombreM, String especie, String aspecto, Portero portero, List<Delantero> delanteros) {
        this.nombre = nombre;
        this.pais = pais;
        this.mascota = new Mascota(nombreM, especie, aspecto);
        this.portero = portero;
        if (delanteros.size() >= 2){
            this.delanteros =delanteros;
        }else {
            throw new IllegalArgumentException("Debe tener almenos 2 delanteros");
        }
    }
    
    public void setPortero(Portero portero){
        this.portero = portero;
    }    
    
    public void inscribirDelantero(Delantero delantero){
        this.delanteros.add(delantero);
    }
    
    public void imprimir(){
        System.out.println("Imprimir informacion del equipo");
        System.out.println("Nombre del equipo: "+ nombre);
        if (portero != null){
            System.out.println("El portero tiene: " +portero.getGolesRecibidos()+" goles recibidos");
        }else {
            System.out.println("Aun no tiene ningun portero.");
        }
        
    }
}
