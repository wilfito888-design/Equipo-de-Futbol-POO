/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.equipofutbol;

import com.mycompany.equipofutbol.model.Delantero;
import com.mycompany.equipofutbol.model.Equipo;
import com.mycompany.equipofutbol.model.Portero;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author pc
 */
public class EquipoFutbol {

    public static void main(String[] args) {
        
        Portero portero1 = new Portero(0, true, "Carlos", "Perez", 20);
        Delantero delantero1 = new Delantero(0, true, "Camilo", "lopez", 25);
        Delantero delantero2 = new Delantero(3, true, "Juan", "lopez", 23);
        
        List<Delantero> delanteros = Arrays.asList(delantero1,delantero2);
        
        Equipo miEquipo = new Equipo("Equipo1", "Colombia");
        Equipo otroEquipo = new Equipo("Equipo2", "Colombia", "Aguila", "ave", "tiene alas", portero1, delanteros);
        
        miEquipo.setPortero(portero1);
        
        miEquipo.imprimir();
        otroEquipo.imprimir();
        
    }
}
